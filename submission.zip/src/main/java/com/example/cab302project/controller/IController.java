package com.example.cab302project.controller;

// Used for controllers that need to inherit parent controller
public interface IController {
    void setMainController(MainController mainController);
}
