# CAB302Project
CAB302 Project
# GitHub Link:
https://github.com/numnum5/StudentHub.git
# Trello Link:
https://trello.com/b/Jkv9MqbM/cab302#
# Figma Link:
https://www.figma.com/proto/ZjND90onnWvnUggJYpbtvU/Student-Hub-Medium-Fidelity-Prototype?node-id=14-2&t=Jfa7dzqDnScpmnjb-1


